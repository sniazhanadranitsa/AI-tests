import React, { useEffect, useState } from "react";
import styles from "./App.module.css";
import { User } from "./types/user";
import { fetchUsers } from "./utils/api";
import UserTable from "./components/UserTable/UserTable";
import UserModal from "./components/UserModal/UserModal";
import Spinner from "./components/Spinner/Spinner";

const App: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  useEffect(() => {
    async function loadData() {
      try {
        const data = await fetchUsers();
        setUsers(data);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleRowClick = (user: User) => {
    setSelectedUser(user);
  };

  const handleCloseModal = () => {
    setSelectedUser(null);
  };

  const handleDeleteUser = (userId: number) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    if (selectedUser && selectedUser.id === userId) {
      setSelectedUser(null);
    }
  };

  return (
    <div className={styles.container}>
      <h1 className={styles.heading}>User Directory</h1>
      {loading && <Spinner />}
      {error && <div className={styles.error}>Ошибка: {error}</div>}
      {!loading && !error && (
        <>
          {users.length > 0 ? (
            <UserTable
              users={users}
              onRowClick={handleRowClick}
              onDelete={handleDeleteUser}
            />
          ) : (
            <div>Пользователи отсутствуют.</div>
          )}
        </>
      )}
      {selectedUser && (
        <UserModal user={selectedUser} onClose={handleCloseModal} />
      )}
    </div>
  );
};

export default App;

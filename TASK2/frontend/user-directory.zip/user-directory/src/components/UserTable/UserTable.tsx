import React from "react";
import { User } from "../../types/user";
import styles from "./UserTable.module.css";

interface Props {
  users: User[];
  onRowClick: (user: User) => void;
  onDelete: (userId: number) => void;
}

const UserTable: React.FC<Props> = ({ users, onRowClick, onDelete }) => {
  return (
    <table className={styles.table}>
      <thead>
        <tr>
          <th>Имя / Email</th>
          <th>Адрес</th>
          <th>Телефон</th>
          <th>Сайт</th>
          <th>Компания</th>
          <th>Действия</th>
        </tr>
      </thead>
      <tbody>
        {users.map((user) => (
          <tr key={user.id} onClick={() => onRowClick(user)} className={styles.row}>
            <td>
              <div className={styles.name}>{user.name}</div>
              <div className={styles.email}>{user.email}</div>
            </td>
            <td>
              {user.address.street}, {user.address.city}
            </td>
            <td>{user.phone}</td>
            <td>
              <a
                href={`http://${user.website}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
              >
                {user.website}
              </a>
            </td>
            <td>{user.company.name}</td>
            <td>
              <button
                className={styles.deleteButton}
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(user.id);
                }}
              >
                Удалить
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default UserTable;

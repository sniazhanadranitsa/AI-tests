import React from "react";
import { User } from "../../types/user";
import styles from "./UserModal.module.css";

interface Props {
  user: User;
  onClose: () => void;
}

const UserModal: React.FC<Props> = ({ user, onClose }) => {
  const { name, username, email, address, phone, website, company } = user;
  const mapUrl = `https://www.google.com/maps?q=${address.geo.lat},${address.geo.lng}`;

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <button className={styles.closeButton} onClick={onClose}>
          ×
        </button>
        <h2 className={styles.title}>{name} ({username})</h2>
        <div className={styles.section}>
          <h3>Контакты</h3>
          <p><strong>Email:</strong> {email}</p>
          <p><strong>Телефон:</strong> {phone}</p>
          <p>
            <strong>Сайт:</strong>{" "}
            <a href={`http://${website}`} target="_blank" rel="noopener noreferrer">
              {website}
            </a>
          </p>
        </div>
        <div className={styles.section}>
          <h3>Адрес</h3>
          <p>
            {address.street}, {address.suite}, {address.city}, {address.zipcode}
          </p>
          <p>
            <a href={mapUrl} target="_blank" rel="noopener noreferrer">
              Открыть в Google Maps
            </a>
          </p>
        </div>
        <div className={styles.section}>
          <h3>Компания</h3>
          <p><strong>Название:</strong> {company.name}</p>
          <p><strong>Описание:</strong> {company.catchPhrase}</p>
          <p><strong>BS:</strong> {company.bs}</p>
        </div>
      </div>
    </div>
  );
};

export default UserModal;

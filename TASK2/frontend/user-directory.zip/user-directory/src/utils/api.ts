import { User } from "../types/user";

const API_URL = "https://jsonplaceholder.typicode.com/users";

export async function fetchUsers(): Promise<User[]> {
  const response = await fetch(API_URL);
  if (!response.ok) {
    throw new Error("Ошибка при загрузке данных пользователей");
  }
  const data: User[] = await response.json();
  return data;
}

# User Directory

This is a React/TypeScript project.

## Instructions

1. Install dependencies: `npm install`
2. Run the project: `npm start`

The folder structure:
```
user-directory/
├── src/
│   ├── components/
│   │   ├── Spinner/
│   │   │   ├── Spinner.tsx
│   │   │   └── Spinner.module.css
│   │   ├── UserTable/
│   │   │   ├── UserTable.tsx
│   │   │   └── UserTable.module.css
│   │   └── UserModal/
│   │       ├── UserModal.tsx
│   │       └── UserModal.module.css
│   ├── types/
│   │   └── user.ts
│   ├── utils/
│   │   └── api.ts
│   ├── App.tsx
│   ├── App.module.css
│   ├── index.tsx
│   └── index.css
└── README.md
```
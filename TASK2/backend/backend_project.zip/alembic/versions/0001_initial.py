from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '0001_initial'
down_revision = None
branch_labels = None
dependency = None

def upgrade():
    op.create_table(
        'users',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('username', sa.String(length=50), unique=True, nullable=False),
        sa.Column('email', sa.String(length=100), unique=True, nullable=False),
        sa.Column('phone', sa.String(length=20)),
        sa.Column('website', sa.String(length=100)),
        sa.Column('street', sa.String(length=100)),
        sa.Column('suite', sa.String(length=100)),
        sa.Column('city', sa.String(length=100)),
        sa.Column('zipcode', sa.String(length=20)),
        sa.Column('lat', sa.String(length=50)),
        sa.Column('lng', sa.String(length=50)),
        sa.Column('company_name', sa.String(length=100)),
        sa.Column('company_catchphrase', sa.String(length=200)),
        sa.Column('company_bs', sa.String(length=200)),
    )
    op.create_table(
        'auth',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.Integer, sa.ForeignKey('users.id', ondelete='CASCADE'), unique=True),
        sa.Column('password_hash', sa.String(length=200), nullable=False)
    )

def downgrade():
    op.drop_table('auth')
    op.drop_table('users')

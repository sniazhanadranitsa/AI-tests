import pytest
from httpx import AsyncClient
from app.main import app
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.config import settings
from app import dependencies, utils, models
import asyncio

DATABASE_URL_TEST = "sqlite:///./test.db"
engine = create_engine(DATABASE_URL_TEST, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Override get_db for testing
async def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

@pytest.fixture(scope="module")
def test_app():
    # Create tables
    Base.metadata.create_all(bind=engine)
    dependencies.SessionLocal = TestingSessionLocal
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.mark.asyncio
async def test_login_and_token(test_app):
    """Test login endpoint and token generation"""
    # Create a test user
    db = TestingSessionLocal()
    hashed_pw = utils.get_password_hash("testpass")
    user = models.User(name="Test User", username="testuser", email="test@example.com", phone="", website="", street="", suite="", city="", zipcode="", lat="", lng="", company_name="", company_catchphrase="", company_bs="")
    db.add(user)
    db.commit()
    auth_record = models.Auth(user_id=user.id, password_hash=hashed_pw)
    db.add(auth_record)
    db.commit()
    db.close()

    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.post("/login", data={"username": "testuser", "password": "testpass"})
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data

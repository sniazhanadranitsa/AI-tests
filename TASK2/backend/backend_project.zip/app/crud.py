from sqlalchemy.orm import Session
from app import models, schemas, utils
from fastapi import HTTPException, status

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

def get_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.User).offset(skip).limit(limit).all()

def create_user(db: Session, user: schemas.UserCreate):
    # Hash password
    hashed_password = utils.get_password_hash(user.password)
    db_user = models.User(
        name=user.name,
        username=user.username,
        email=user.email,
        phone=user.phone,
        website=user.website,
        street=user.address.street,
        suite=user.address.suite,
        city=user.address.city,
        zipcode=user.address.zipcode,
        lat=user.address.geo.lat,
        lng=user.address.geo.lng,
        company_name=user.company.name,
        company_catchphrase=user.company.catchPhrase,
        company_bs=user.company.bs,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    # Create auth record
    auth_record = models.Auth(user_id=db_user.id, password_hash=hashed_password)
    db.add(auth_record)
    db.commit()
    return db_user

def update_user(db: Session, user_id: int, user_update: schemas.UserUpdate):
    db_user = get_user(db, user_id)
    if not db_user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if user_update.name:
        db_user.name = user_update.name
    if user_update.username:
        db_user.username = user_update.username
    if user_update.email:
        db_user.email = user_update.email
    if user_update.phone is not None:
        db_user.phone = user_update.phone
    if user_update.website is not None:
        db_user.website = user_update.website
    if user_update.address:
        db_user.street = user_update.address.street
        db_user.suite = user_update.address.suite
        db_user.city = user_update.address.city
        db_user.zipcode = user_update.address.zipcode
        db_user.lat = user_update.address.geo.lat
        db_user.lng = user_update.address.geo.lng
    if user_update.company:
        db_user.company_name = user_update.company.name
        db_user.company_catchphrase = user_update.company.catchPhrase
        db_user.company_bs = user_update.company.bs
    if user_update.password:
        hashed_password = utils.get_password_hash(user_update.password)
        db_user.auth.password_hash = hashed_password
    db.commit()
    db.refresh(db_user)
    return db_user

def delete_user(db: Session, user_id: int):
    db_user = get_user(db, user_id)
    if not db_user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    db.delete(db_user)
    db.commit()
    return {"detail": "User deleted"}

import json
from sqlalchemy.orm import Session
from app import models, utils, dependencies

seed_json = [
    # Paste JSONPlaceholder /users array here
]

def seed(db: Session):
    for item in seed_json:
        user = models.User(
            id=item['id'],
            name=item['name'],
            username=item['username'],
            email=item['email'],
            phone=item.get('phone'),
            website=item.get('website'),
            street=item['address']['street'],
            suite=item['address']['suite'],
            city=item['address']['city'],
            zipcode=item['address']['zipcode'],
            lat=item['address']['geo']['lat'],
            lng=item['address']['geo']['lng'],
            company_name=item['company']['name'],
            company_catchphrase=item['company']['catchPhrase'],
            company_bs=item['company']['bs'],
        )
        db.add(user)
        # Default password: "password"
        hashed = utils.get_password_hash("password")
        auth_record = models.Auth(user_id=item['id'], password_hash=hashed)
        db.add(auth_record)
    db.commit()

if __name__ == "__main__":
    db = dependencies.SessionLocal()
    seed(db)
    db.close()

# FastAPI JSONPlaceholder Backend

## Setup
1. Clone repository
2. Copy `.env.example` to `.env` and set environment variables
3. Run `docker-compose up --build` to start services
4. Execute migrations: `docker-compose exec web alembic upgrade head`
5. Seed data: `docker-compose exec web python app/seed_data.py`
6. Access API at `http://localhost:8000`
7. API docs: `http://localhost:8000/docs`

## API Endpoints
- `POST /login`: Obtain JWT token
- `GET /users/`: List users (requires token)
- `GET /users/{id}`: Get user by ID (requires token)
- `POST /users/`: Create new user (requires token)
- `PUT /users/{id}`: Update user (requires token)
- `DELETE /users/{id}`: Delete user (requires token)

## Testing
```
pytest
```

## Codegen Rules
See `rules.yaml` and `plan.yaml` for code generation guidelines.

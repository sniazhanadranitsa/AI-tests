/**
 * api_test.js
 *
 * Скрипт выполняет GET-запрос к fakestoreapi.com/products,
 * проверяет код ответа и для каждого продукта валидирует:
 *  - title !== ""
 *  - price >= 0
 *  - rating.rate <= 5
 * После этого выводит список продуктов с дефектами в консоль.
 */

import fetch from 'node-fetch';

async function validateProducts() {
    const url = 'https://fakestoreapi.com/products';

    try {
        const response = await fetch(url);
        // Проверяем код ответа
        if (response.status !== 200) {
            console.error(\`Ошибка: HTTP \${response.status}\`);
            return;
        }

        const products = await response.json();

        const defectiveProducts = [];

        products.forEach(product => {
            const defects = [];

            // Проверяем title
            if (!product.title || product.title.trim().length === 0) {
                defects.push('Пустой title');
            }

            // Проверяем price
            if (typeof product.price !== 'number' || product.price < 0) {
                defects.push(\`Неправильный price (\${product.price})\`);
            }

            // Проверяем rating.rate (если рейтинг есть)
            if (product.rating) {
                if (typeof product.rating.rate !== 'number' || product.rating.rate > 5) {
                    defects.push(\`rating.rate > 5 (\${product.rating.rate})\`);
                }
            } else {
                defects.push('Отсутствует поле rating');
            }

            if (defects.length > 0) {
                defectiveProducts.push({
                    id: product.id,
                    title: product.title,
                    defects
                });
            }
        });

        if (defectiveProducts.length === 0) {
            console.log('Дефектные продукты не найдены. Все проверки пройдены.');
        } else {
            console.log('Найдены продукты с дефектами:');
            defectiveProducts.forEach(prod => {
                console.log(`\nID: ${prod.id}`);
                console.log(`Title: ${prod.title}`);
                console.log('Дефекты:');
                prod.defects.forEach(d => console.log(`  — ${d}`));
            });
        }
    } catch (err) {
        console.error('Ошибка при выполнении запроса:', err);
    }
}

// Запуск проверки
validateProducts();

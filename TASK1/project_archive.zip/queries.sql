-- SQL-запросы для анализа базы данных онлайн

-- 1. Общий объём продаж за март 2024
SELECT SUM(amount) AS total_march
FROM orders
WHERE strftime('%Y-%m', order_date) = '2024-03';

-- 2. Клиент, который потратил больше всего за всё время
SELECT customer, SUM(amount) AS total_spent
FROM orders
GROUP BY customer
ORDER BY total_spent DESC
LIMIT 1;

-- 3. Средняя стоимость заказа за период 2024-02-01 … 2024-04-30
SELECT ROUND(AVG(amount), 2) AS avg_order_3months
FROM orders
WHERE order_date BETWEEN '2024-02-01' AND '2024-04-30';
